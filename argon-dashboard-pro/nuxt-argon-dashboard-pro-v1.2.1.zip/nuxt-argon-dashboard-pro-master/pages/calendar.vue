<template>
  <div>
    <no-ssr>
      <big-calendar></big-calendar>
    </no-ssr>
  </div>
</template>
<script>
  export default {
    layout: 'DashboardLayout'
  }
</script>
